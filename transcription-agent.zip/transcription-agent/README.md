# 武侠小说转写 Agent 设计包

## 目标

将用户输入、角色 Agent 输出、旁白 Agent 输出和故事状态，转写为原创中文武侠小说片段。`jin-yong-perspective` Skill 只提供金庸武侠创作方法与表达特征；本 Agent 负责素材融合、事实约束和结构化输出。

## 重要说明

不得要求模型复制金庸原文、固定句子或直接冒充金庸本人。应使用 Skill 提炼的公开创作特征：浅白为底、文言点睛、江湖感、人物灰度、草蛇灰线、武学与人格关联、张弛节奏和章末悬念。

## Skill 使用

- Skill 名称：`jin-yong-perspective`
- 本机安装位置：`/Users/shuke/.codex/skills/jin-yong-perspective`
- 调用方式：在转写 Agent 的运行上下文中加载该 Skill，作为风格与创作方法参考。
- Skill 不负责读取故事状态、不负责决定剧情、不负责保存章节。

团队交付时应把 Skill 作为依赖说明，不要把整个 Skill 内容复制进每次请求。若部署环境不能自动加载 Skill，则将其核心风格规则编译进 `prompts/system.md`。

## 调用规则是否需要交付

需要。调用规则是接口契约，不应只依赖主 Agent 的临时判断。主 Agent 可以自动调用，但应遵守 `rules/invocation.md`；这样团队可以测试、替换主 Agent 或迁移到其他编排器。
